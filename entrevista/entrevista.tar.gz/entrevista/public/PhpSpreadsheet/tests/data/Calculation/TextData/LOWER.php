<?php

return [
    [
        'abcdefghi',
        'AbCdEfGhI',
    ],
    [
        'mark baker',
        'MARK BAKER',
    ],
    [
        'true',
        true,
    ],
    [
        'false',
        false,
    ],
];
