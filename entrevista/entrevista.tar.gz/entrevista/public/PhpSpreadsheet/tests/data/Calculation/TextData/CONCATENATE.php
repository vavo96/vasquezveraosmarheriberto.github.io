<?php

return [
    [
        'ABCDEFGHIJ',
        'ABCDE',
        'FGHIJ',
    ],
    [
        '123',
        1,
        2,
        3,
    ],
    [
        'Boolean-TRUE',
        'Boolean',
        '-',
        true,
    ],
];
