<?php

return [
    [
        0,
        null,
    ],
    [
        0,
        '',
    ],
    [
        9,
        'AbCdEfGhI',
    ],
    [
        10,
        'MARK BAKER',
    ],
    [
        4,
        true,
    ],
    [
        5,
        false,
    ],
];
