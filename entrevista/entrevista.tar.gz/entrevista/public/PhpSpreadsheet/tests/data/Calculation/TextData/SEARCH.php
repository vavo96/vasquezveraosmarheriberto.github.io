<?php

return [
    [
        3,
        'E',
        'QWERTYUIOP',
    ],
    [
        4,
        'D',
        'ABCDEFGHI',
    ],
    [
        4,
        'E',
        true,
    ],
    [
        5,
        'E',
        false,
    ],
    [
        2,
        'A',
        'Mark Baker',
    ],
    [
        '#VALUE!',
        'C',
        'Mark Baker',
    ],
    [
        7,
        'A',
        'Mark Baker',
        3,
    ],
    [
        4,
        'K',
        'Mark Baker',
    ],
    [
        8,
        'K',
        'Mark Baker',
        5,
    ],
    [
        2,
        'A',
        'Mark Baker',
        2,
    ],
    [
        '#VALUE!',
        'BITE',
        'BIT',
    ],
];
