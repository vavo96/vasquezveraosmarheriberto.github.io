<?php

// Cost, Date purchased, End of the 1st period, Salvage, Period, Depreciation, Basis, Result

return [
    [
        360,
        2400,
        '2008-08-19',
        '2008-12-31',
        300,
        1,
        0.14999999999999999,
        1,
    ],
    [
        30,
        150,
        '2011-01-01',
        '2011-09-30',
        20,
        1,
        0.20000000000000001,
        4,
    ],
];
