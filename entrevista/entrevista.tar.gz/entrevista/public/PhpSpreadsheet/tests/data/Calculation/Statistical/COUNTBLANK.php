<?php

return [
    [
        4,
        [-1, null, 0, '', 1, null, 2, '', 3],
    ],
];
